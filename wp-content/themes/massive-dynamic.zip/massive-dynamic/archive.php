<?php
/**
 * Archive template (blog/posts)
 */
pixflow_generate_page('blog');
