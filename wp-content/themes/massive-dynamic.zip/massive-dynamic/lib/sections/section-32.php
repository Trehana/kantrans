<?php
$section_params = array(
	'row_padding_top'=>'150'
,'row_section_id_description'=>''
,'row_padding_bottom'=>'140'
,'row_type_width_description' => ''
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'


, 'content' => '[vc_column width="1/3" css=".vc_custom_1468226070144{padding-right: 15px !important;}" el_class="responsive-col-50"][md_article_box article_image="http://theme.pixflow.net/massive-dynamic/section/section-32/section32-img0.jpg" article_title="Unique Elements" article_icon="icon-like" article_height="440" article_overlay_color="rgb(4, 61, 160)" article_icon_color="rgb(255, 255, 255)"][/md_article_box][vc_empty_space height="10"][/vc_empty_space][/vc_column][vc_column width="1/3" css=".vc_custom_1468226057782{padding-right: 15px !important;padding-left: 15px !important;}" el_class="responsive-col-50"][md_article_box article_image="http://theme.pixflow.net/massive-dynamic/section/section-32/section32-img.jpg" article_title="Corporate Shortcode" article_icon="icon-settings" article_height="441" article_overlay_color="rgb(4, 61, 160)" article_icon_color="rgb(255, 255, 255)"][/md_article_box][/vc_column][vc_column width="1/3" css=".vc_custom_1468226046374{padding-left: 15px !important;}" el_class="responsive-full-width"][md_info_box info_box_title="Planning for the future." info_box_icon_class="icon-empty" info_box_border_color="#20d6be" info_box_button_icon_class="icon-empty" info_box_button_color="rgb(32, 214, 190)" info_box_button_bg_hover_color="rgb(3, 56, 162)"][/md_info_box][/vc_column]'
);




