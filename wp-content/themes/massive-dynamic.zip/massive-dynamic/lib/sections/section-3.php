<?php
$section_params = array(
       'row_type' => "image"
     , 'type_width' =>'full_size'
     ,'row_fit_to_height'=>'no'
    ,'box_size_states'=>'content_box_size'
    ,'el_class'=>''
    ,'row_vertical_align'=>'no'
    ,'row_equal_column_heigh'=>'no'
    ,'row_content_vertical_align'=>'0'
    ,'row_section_id'=>'intro-section'
    ,'row_padding_top'=>'280'
    ,'row_padding_bottom'=>'280'
    ,'row_padding_right'=>'0'
    ,'row_padding_left'=>'0'
    ,'row_margin_top'=>'0'
    ,'row_margin_bottom'=>'0'
    ,'background_color'=>'rgba(255,255,255,1)'
    ,'row_webm_url'=>''
    ,'row_mp4_url'=>''
    ,'background_color_image'=>'rgba(0, 0, 0, 0)'
    ,'row_image'=>'http://theme.pixflow.net/massive-dynamic/section/section-3/2.jpg'
    ,'row_image_position'=>'default'
    ,'row_bg_image_size_tab_image'=>'cover'
    ,'row_bg_repeat_image_gp='=>'no'
    ,'first_color'=>'#000'
    ,'second_color'=>'#000'
    ,'row_gradient_color'=>'pixflow_base64eyJjb2xvcjEiOiIjZmZmIiwiY29sb3IyIjoicmdiYSgyNTUsMjU1LDI1NSwwKSIsImNvbG9yMVBvcyI6IjAuMDAiLCJjb2xvcjJQb3MiOiIxMDAuMDAiLCJhbmdsZSI6MH0='
    ,'row_image_position_gradient'=>'fit'
    ,' row_bg_image_size_tab_gradient'=>'cover'
    ,'row_bg_repeat_gradient_gp'=>'no'
    ,'row_inner_shadow'=>'no'
    ,'row_sloped_edge'=>'no'
    ,'row_slope_edge_position'=>'top'
    ,'row_sloped_edge_color'=>'#000'
    ,'row_sloped_edge_angle'=>'-3'
    ,'parallax_status'=>'no'
    ,'parallax_speed'=>'1'


     , 'content' => '[vc_column width="12/12"][md_live_text meditor_letter_spacing="0"  meditor_line_height="1"  md_live_text_animation="yes" md_live_text_animation_type="fade" md_live_text_animation_speed="800" md_live_text_animation_delay="0" md_live_text_animation_position="bottom" md_live_text_animation_show="scroll" md_live_text_animation_easing="Power4.easeOut" md_live_text_parallax_speed="1"]CiAgICAgICAgICAgICAgICA8ZGl2PgogICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8ZGl2PgogICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICA8ZGl2PgogICAgICAgICAgICAgICAgICAgPGgyPjxzcGFuIHN0eWxlPSJmb250LXNpemU6IDk1cHg7IGNvbG9yOiByZ2IoMjU1LCAyNTUsIDI1NSk7IGxpbmUtaGVpZ2h0OiAxZW07IGZvbnQtd2VpZ2h0OiA3MDA7IGZvbnQtc3R5bGU6IG5vcm1hbDsgZm9udC1mYW1pbHk6IE1vbnRzZXJyYXQ7IiBjbGFzcz0iIiBkYXRhLWZvbnQtd2VpZ2h0PSI3MDAiPkNyZWF0aXZlPGJyPjwvc3Bhbj48c3BhbiBzdHlsZT0iZm9udC1zaXplOiA5NXB4OyBjb2xvcjogcmdiKDI1NSwgMjU1LCAyNTUpOyBsaW5lLWhlaWdodDogMWVtOyBmb250LXdlaWdodDogNzAwOyBmb250LXN0eWxlOiBub3JtYWw7IGZvbnQtZmFtaWx5OiBNb250c2VycmF0OyIgY2xhc3M9IiIgZGF0YS1mb250LXdlaWdodD0iNzAwIj5QcmVzZW50YXRpb24gSWRlYXM8L3NwYW4+PC9oMj48ZGl2Pjxicj48L2Rpdj48ZGl2Pjxicj48L2Rpdj48ZGl2Pjxicj48L2Rpdj4gICAgICAgICAgICAgICAgPC9kaXY+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA=[/md_live_text][md_button button_style="come-in" button_size="standard" left_right_padding="9" button_align="center" button_text="LEARN MORE" button_icon_class="icon-empty" button_color="rgb(255, 255, 255)" button_text_color="#fff" button_bg_hover_color="#9b9b9b" button_hover_color="rgb(6, 6, 6)" button_url="#" button_target="_self" md_button_animation="yes" md_button_animation_type="fade" md_button_animation_speed="800" md_button_animation_delay="0.0" md_button_animation_position="bottom" md_button_animation_show="scroll" md_button_animation_easing="Power4.easeOut" md_button_parallax_speed="1" align="center"][/md_button][/vc_column]'
);





