<?php
$section_params = array(
	'row_padding_top'=>'200'
,'row_padding_bottom'=>'200'
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'
,'background_color'=>'rgb(34, 34, 34)'
,'row_section_id_description'=>''
,'row_type_width_description'=>''

, 'content' => '[vc_column width="1/4" el_id=\'57cf93b34e971\'][md_counter counter_title_color="rgb(255, 255, 255)" counter_icon_class="icon-sound" counter_icon_color="rgb(35, 121, 210)" md_counter_animation="no"][/md_counter][/vc_column][vc_column width="1/4" el_id=\'57cf93b34e9b9\'][md_counter counter_to="206" counter_title="Team members" counter_title_color="rgb(255, 255, 255)" counter_icon_class="icon-layers4" counter_icon_color="rgb(35, 121, 210)" md_counter_animation="no"][/md_counter][/vc_column][vc_column width="1/4" el_id=\'57cf93b34ea04\'][md_counter counter_to="84" counter_title="Connection" counter_title_color="rgb(255, 255, 255)" counter_icon_class="icon-camera-1" counter_icon_color="rgb(35, 121, 210)" md_counter_animation="no"][/md_counter][/vc_column][vc_column width="1/4" el_id=\'57cf93b34ea36\'][md_counter counter_to="112" counter_title="Clients" counter_title_color="rgb(255, 255, 255)" counter_icon_class="icon-cloud-upload" counter_icon_color="rgb(35, 121, 210)" md_counter_animation="no"][/md_counter][/vc_column]'
);
