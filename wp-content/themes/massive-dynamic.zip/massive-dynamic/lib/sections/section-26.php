<?php
$section_params = array(
	'row_type' => "image"
, 'type_width' =>'full_size'
,'row_fit_to_height'=>'no'
,'box_size_states'=>'content_box_size'
,'el_class'=>''
,'row_vertical_align'=>'no'
,'row_equal_column_heigh'=>'no'
,'row_content_vertical_align'=>'0'
,'row_padding_top'=>'130'
,'row_padding_bottom'=>'130'
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'
,'background_color'=>'rgba(255,255,255,1)'
,'row_webm_url'=>''
,'row_mp4_url'=>''
,'background_color_image'=>'rgba(111, 218, 75, 0)'
,'row_image_position'=>'default'
,'row_bg_image_size_tab_image'=>'cover'
,'row_bg_repeat_image_gp='=>'no'
,'first_color'=>'#000'
,'second_color'=>'#000'
,'row_gradient_color'=>'pixflow_base64eyJjb2xvcjEiOiIjZmZmIiwiY29sb3IyIjoicmdiYSgyNTUsMjU1LDI1NSwwKSIsImNvbG9yMVBvcyI6IjAuMDAiLCJjb2xvcjJQb3MiOiIxMDAuMDAiLCJhbmdsZSI6MH0='
,'row_image_position_gradient'=>'fit'
,' row_bg_image_size_tab_gradient'=>'cover'
,'row_bg_repeat_gradient_gp'=>'no'
,'row_inner_shadow'=>'no'
,'row_sloped_edge'=>'no'
,'row_slope_edge_position'=>'top'
,'row_sloped_edge_color'=>'#000'
,'row_sloped_edge_angle'=>'-3'
,'parallax_status'=>'yes'
,'parallax_speed'=>'7'
,'row_image' => 'http://theme.pixflow.net/massive-dynamic/section/section-26/b1.jpg'

, 'content' => '[vc_column width="2/12" el_id=\'5819aa83e7265\'][/vc_column][vc_column width="8/12"][md_testimonial_carousel testimonial_carousel_num="2" testimonial_carousel_text_color="rgb(218, 218, 218)" testimonial_carousel_text_size="h6" testimonial_carousel_img_1="http://theme.pixflow.net/massive-dynamic/section/section-26/b2.jpg" testimonial_carousel_name_1="Rivera Group" testimonial_carousel_job_name_1="Graphic Designer, Allbarnds Magazine" testimonial_carousel_desc_1="orem ipsum dolor sit amet, nec in adipiscing purus luctus, urna in lorem nec fringilla vel, non sed arcu integevestibulum in lorem nec" testimonial_carousel_img_2="http://theme.pixflow.net/massive-dynamic/section/section-26/b3.jpg" testimonial_carousel_name_2="Mari Javani" testimonial_carousel_job_name_2="Graphic Designer, Allbarnds Magazine" testimonial_carousel_desc_2="orem ipsum dolor sit amet, nec in adipiscing purus luctus, urna pellentesque fringilla vel, non sed arcu integevestibulum in lorem nec" testimonial_carousel_name_3="Mari Javani" testimonial_carousel_job_name_3="Graphic Designer, Stupids Magazine" testimonial_carousel_desc_3="orem ipsum dolor sit amet, nec in adipiscing purus luctus, urna pellentesque fringilla vel, non sed arcu integevestibulum in lorem nec" testimonial_carousel_name_4="Mari Javani" testimonial_carousel_job_name_4="Graphic Designer, Stupids Magazine" testimonial_carousel_desc_4="orem ipsum dolor sit amet, nec in adipiscing purus luctus, urna pellentesque fringilla vel, non sed arcu integevestibulum in lorem nec" testimonial_carousel_name_5="Mari Javani" testimonial_carousel_job_name_5="Graphic Designer, Stupids Magazine" testimonial_carousel_desc_5="orem ipsum dolor sit amet, nec in adipiscing purus luctus, urna pellentesque fringilla vel, non sed arcu integevestibulum in lorem nec" md_testimonial_carousel_animation_type="fade" md_testimonial_carousel_animation_speed="400" md_testimonial_carousel_animation_delay="0.0" md_testimonial_carousel_animation_position="center" md_testimonial_carousel_animation_show="once" md_testimonial_carousel_animation_easing="Quart.easeInOut" md_testimonial_carousel_parallax_speed="1"][/md_testimonial_carousel][/vc_column][vc_column width="2/12"][/vc_column]'
);





