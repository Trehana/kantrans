<?php
$section_params = array(
	'row_type' => "image"
, 'type_width' =>'full_size'
,'row_fit_to_height'=>'no'
,'box_size_states'=>'content_box_size'
,'el_class'=>''
,'row_vertical_align'=>'no'
,'row_equal_column_heigh'=>'no'
,'row_content_vertical_align'=>'0'
,'row_padding_top'=>'260'
,'row_padding_bottom'=>'260'
,'row_padding_right'=>'0'
,'row_padding_left'=>'0'
,'row_margin_top'=>'0'
,'row_margin_bottom'=>'0'
,'background_color'=>'rgba(255,255,255,1)'
,'row_webm_url'=>''
,'row_mp4_url'=>''
,'background_color_image'=>'rgba(0, 0, 0, 0.71)'
,'row_image_position'=>'default'
,'row_bg_image_size_tab_image'=>'cover'
,'row_bg_repeat_image_gp='=>'no'
,'first_color'=>'#000'
,'second_color'=>'#000'
,'row_gradient_color'=>'pixflow_base64eyJjb2xvcjEiOiIjZmZmIiwiY29sb3IyIjoicmdiYSgyNTUsMjU1LDI1NSwwKSIsImNvbG9yMVBvcyI6IjAuMDAiLCJjb2xvcjJQb3MiOiIxMDAuMDAiLCJhbmdsZSI6MH0='
,'row_image_position_gradient'=>'fit'
,' row_bg_image_size_tab_gradient'=>'cover'
,'row_bg_repeat_gradient_gp'=>'no'
,'row_inner_shadow'=>'no'
,'row_sloped_edge'=>'no'
,'row_slope_edge_position'=>'top'
,'row_sloped_edge_color'=>'#000'
,'row_sloped_edge_angle'=>'-3'
,'parallax_status'=>'no'
,'parallax_speed'=>'1'
,'align' => 'no'
,'row_image' => "http://theme.pixflow.net/massive-dynamic/section/section-19/section19-1.jpg"

, 'content' => '[vc_column width="4/12" el_id=\'59db469e01408\' css=".vc_column-inner.md_col-59e460b266efb{padding-right:67px!important;padding-left:0px!important;}"     padding_right="67"    padding_left="0"][md_iconbox_side2 iconbox_side2_icon="icon-PriceTag" iconbox_side2_title="" iconbox_side2_small_title_color="#12be83" iconbox_side2_title_big="Be Social" iconbox_side2_description="198 West 21th Street, Suite 721 
New York NY10010
 Email: youremail@yourdomain.com 
Phone: +88 (0) 101 0000 000" iconbox_side2_title_big_heading="h6" iconbox_side2_type="icon" iconbox_side2_alignment="left" iconbox_side2_general_color="rgb(255, 255, 255)" iconbox_side2_icon_color="rgb(115, 174, 32)" iconbox_side2_button="no" iconbox_side2_button_style="fade-square" iconbox_side2_button_text="Read more" iconbox_side2_class="icon-empty" iconbox_side2_button_color="#5e5e5e" iconbox_side2_button_text_color="#fff" iconbox_side2_button_bg_hover_color="#9b9b9b" iconbox_side2_button_hover_color="#FFF" iconbox_side2_button_size="standard" iconbox_side2_left_right_padding="0" iconbox_side2_button_url="#" iconbox_side2_button_target="_self" md_iconbox_side2_animation_type="fade" md_iconbox_side2_animation_speed="200" md_iconbox_side2_animation_delay="0.0" md_iconbox_side2_animation_position="center" md_iconbox_side2_animation_show="once" md_iconbox_side2_animation_easing="Quart.easeInOut" md_iconbox_side2_parallax_speed="1"][/md_iconbox_side2][/vc_column][vc_column width="4/12" el_id=\'59db469e023af\' css=".vc_column-inner.md_col-59e460b26f59f{padding-right:39px!important;padding-left:26px!important;}"        padding_right="39"     padding_left="26"][md_iconbox_side2 iconbox_side2_icon="icon-ChatConversation2" iconbox_side2_title="" iconbox_side2_small_title_color="#12be83" iconbox_side2_title_big="Via Telephone" iconbox_side2_description="198 West 21th Street, Suite 721 
New York NY10010
 Email: youremail@yourdomain.com 
Phone: +88 (0) 101 0000 000" iconbox_side2_title_big_heading="h6" iconbox_side2_type="icon" iconbox_side2_alignment="left" iconbox_side2_general_color="rgb(255, 255, 255)" iconbox_side2_icon_color="rgb(115, 174, 32)" iconbox_side2_button="no" iconbox_side2_button_style="fade-square" iconbox_side2_button_text="Read more" iconbox_side2_class="icon-empty" iconbox_side2_button_color="#5e5e5e" iconbox_side2_button_text_color="#fff" iconbox_side2_button_bg_hover_color="#9b9b9b" iconbox_side2_button_hover_color="#FFF" iconbox_side2_button_size="standard" iconbox_side2_left_right_padding="0" iconbox_side2_button_url="#" iconbox_side2_button_target="_self" md_iconbox_side2_animation_type="fade" md_iconbox_side2_animation_speed="200" md_iconbox_side2_animation_delay="0.0" md_iconbox_side2_animation_position="center" md_iconbox_side2_animation_show="once" md_iconbox_side2_animation_easing="Quart.easeInOut" md_iconbox_side2_parallax_speed="1"][/md_iconbox_side2][/vc_column][vc_column width="4/12" el_id=\'59db469e0334d\' css=".vc_column-inner.md_col-59e460b27778d{padding-left:44px!important;padding-right:23px!important;}"     padding_left="44"  padding_right="23"][md_iconbox_side2 iconbox_side2_icon="icon-Bookmark2" iconbox_side2_title="" iconbox_side2_small_title_color="#12be83" iconbox_side2_title_big="Nostalgic" iconbox_side2_description="198 West 21th Street, Suite 721 
New York NY10010
 Email: youremail@yourdomain.com 
Phone: +88 (0) 101 0000 000" iconbox_side2_title_big_heading="h6" iconbox_side2_type="icon" iconbox_side2_alignment="left" iconbox_side2_general_color="rgb(255, 255, 255)" iconbox_side2_icon_color="rgb(115, 174, 32)" iconbox_side2_button="no" iconbox_side2_button_style="fade-square" iconbox_side2_button_text="Read more" iconbox_side2_class="icon-empty" iconbox_side2_button_color="#5e5e5e" iconbox_side2_button_text_color="#fff" iconbox_side2_button_bg_hover_color="#9b9b9b" iconbox_side2_button_hover_color="#FFF" iconbox_side2_button_size="standard" iconbox_side2_left_right_padding="0" iconbox_side2_button_url="#" iconbox_side2_button_target="_self" md_iconbox_side2_animation_type="fade" md_iconbox_side2_animation_speed="200" md_iconbox_side2_animation_delay="0.0" md_iconbox_side2_animation_position="center" md_iconbox_side2_animation_show="once" md_iconbox_side2_animation_easing="Quart.easeInOut" md_iconbox_side2_parallax_speed="1"][/md_iconbox_side2][/vc_column]'
);
