<?php
$section_params = array(
  'box_size_states' => "content_full_size"
, 'background_color' => "rgb(253, 253, 253)"
, 'row_padding_top' => "0"
, 'row_section_id_description' =>''
, 'row_padding_bottom' => "0"
, 'row_type_width_description' =>''
, 'row_padding_right' => "0"
, 'row_padding_left' => "0"
, 'row_margin_top' => "0"
, 'row_margin_bottom' => "0"
, 'content' => '[vc_column][md_double_slider slide_num="2" double_slider_duration="7" double_slider_height="680" slide_bg_1="#623e95" slide_title_1="We have never been so happy before" slide_sub_title_1="Now You Know Us" slide_description_1="Now You Know Us
We have never been so happy beforeMassive Dynamic has over 10 years of experience in Design, Technology and Marketing. We take pride in delivering Intelligent Designs and Engaging." slide_bg_2="rgb(98, 62, 149)" slide_title_2="We have never been so happy before" slide_sub_title_2="Now You Know Us" slide_description_2="Now You Know Us
We have never been so happy beforeMassive Dynamic has over 10 years of experience in Design, Technology and Marketing. We take pride in delivering Intelligent Designs and Engaging." slide_image_1="http://theme.pixflow.net/massive-dynamic/section/section-9/img-section.jpg" slide_image_2="http://theme.pixflow.net/massive-dynamic/section/section-9/sub-img.jpg" md_double_slider_animation="no"][/md_double_slider][/vc_column]'
);

