<?php
/**
 * 404 (Page not found) template
 */


pixflow_generate_page('404');
